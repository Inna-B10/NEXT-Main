import Image from "next/image";

export default function Home() {
  return (
    <main className="grid gap-8 place-content-center min-h-screen">
      <h1>About page</h1>
     


    </main>
  );
}
